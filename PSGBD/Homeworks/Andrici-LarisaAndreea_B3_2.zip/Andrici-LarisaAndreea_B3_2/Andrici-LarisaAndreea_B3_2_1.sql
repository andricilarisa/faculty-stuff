--Exercitiul 1
set serveroutput on;

accept x prompt 'Introdu un sir de caractere: ';

DECLARE
charactersToFind VARCHAR(30):='&x';
nameStudent users.name%type;
numberOfStudents number(4):=0;
pozStudent NUMBER(5):=TRUNC(DBMS_RANDOM.VALUE(2,numberOfStudents));
idStudent users.id%type;
secondName users.name%type;
nrQuestions number(2):=0;

BEGIN
SELECT count(name) into numberOfStudents from USERS where INSTR(NAME,charactersToFind)!=0 order by id;
DBMS_OUTPUT.PUT_LINE('Numarul de studenti: '||numberOfStudents);
DBMS_OUTPUT.PUT_LINE('Numar random: '||pozStudent);
SELECT id into idStudent from (SELECT rownum as poz, id from ( select id from users WHERE INSTR(name,charactersToFind)!=0 order by id))
WHERE poz=pozStudent;

DBMS_OUTPUT.PUT_LINE('Id-ul studentului: '||idStudent);
select upper(substr(name,1, instr(name, ' '))) into nameStudent from USERS where id=idStudent;
DBMS_OUTPUT.PUT_LINE(nameStudent);
select initcap(substr(name,instr(name, ' '),length(name))) into secondName from USERS where id=idStudent;
DBMS_OUTPUT.PUT_LINE(secondName);

END;
