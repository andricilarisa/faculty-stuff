set serveroutput on;
--Exercitiul 2
<<global>>
DECLARE
 v_varsta integer:=21;
BEGIN
 --Se va aflisa valoarea 21
     DBMS_OUTPUT.PUT_LINE(v_varsta);
        DECLARE
          v_varsta integer:=5;
          BEGIN
 --Se va afisa valoarea 5
           DBMS_OUTPUT.PUT_LINE(v_varsta);
 --Se va afisa valoarea declarata global 21
           DBMS_OUTPUT.PUT_LINE(global.v_varsta);
              DECLARE
                v_varsta integer:=9;
                BEGIN
 --Se va afisa valoarea 9
                DBMS_OUTPUT.PUT_LINE(v_varsta);
 --Se va afisa valoarea declarata global 21
                DBMS_OUTPUT.PUT_LINE(global.v_varsta);
                END;
         END;
END;