--Exercitiul 3
set serveroutput on;

DECLARE
idStudent1 QUESTIONS.USER_ID%type;
idStudent2 QUESTIONS.USER_ID%type;
nameStud1 users.username%type;
nameStud2 users.username%type;
nr_questionsStud1 number(5);
nr_questionsStud2 number(5);
nr_answersStud1 number(5);
nr_answersStud2 number(5);

BEGIN
idStudent1:=123;
idStudent2:=432;
SELECT count(idStudent1) into nr_questionsStud1 from QUESTIONS where user_id=idStudent1;
SELECT count(idStudent2) into nr_questionsStud2 from QUESTIONS where user_id=idStudent2;
SELECT username into nameStud1 from users where id=idStudent1;
SELECT username into nameStud2 from users where id=idStudent2;
SELECT count(idStudent1) into nr_answersStud1 from ANSWERS where user_id=idStudent1;
SELECT count(idStudent2) into nr_answersStud2 from ANSWERS where user_id=idStudent2;

IF(nr_questionsStud1>nr_questionsStud2) 
THEN
DBMS_OUTPUT.PUT_LINE('Studentul cu mai multe intrebari dintre ' || nameStud1 ||' si '|| nameStud2|| ' este: ' || nameStud1 );
ELSIF (nr_questionsSTud1=nr_questionsStud2 AND nr_answersStud1>nr_answersStud2)
THEN
DBMS_OUTPUT.PUT_LINE('Studentii au nr de intrebari egale, astfel studentul care are mai multe raspunsuri dintre '|| nameStud1 ||' si '|| nameStud2|| ' este: ' || nameStud1 );
ELSIF(nr_questionsSTud1=nr_questionsStud2 AND nr_answersStud1<nr_answersStud2)
THEN
DBMS_OUTPUT.PUT_LINE('Studentii au nr de intrebari egale, astfel studentul care are mai multe raspunsuri dintre '|| nameStud1 ||' si '|| nameStud2|| ' este: ' || nameStud2 );
ELSE
DBMS_OUTPUT.PUT_LINE('Studentul cu mai multe intrebari dintre ' || nameStud1 ||' si '|| nameStud2|| ' este: ' || nameStud2 );
END IF;
END;