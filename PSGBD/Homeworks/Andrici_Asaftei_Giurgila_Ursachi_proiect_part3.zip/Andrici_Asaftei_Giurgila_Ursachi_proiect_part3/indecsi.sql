--index 0
select * from useri where EMAIL = 'CLARK.Sophia@gmail.com';
create index useri_email on USERI (email);
drop index useri_email;

-- index 1
create index p6 on view_useri (username);

drop index p6;

select username from view_useri;

--index 2

create index restrictii_index on restrictii (id_user);

drop index restrictii_index;

create or replace function in_comun (p_id1 int, p_id2 int) RETURN int as
    v_count int:=0;
    v_restrictii int:=0;
    cursor restrictii_id1 is select * from restrictii where id_user=p_id1;
BEGIN
    for v_line in restrictii_id1 loop
        select count(id_user) into v_count from restrictii where id_prop=v_line.id_prop and v_line.id_user=p_id2;
        if v_count <> 0 then v_restrictii := v_restrictii + 1;
        end if;
        v_count :=0;
    end loop;
    return v_restrictii;
END;


set serveroutput on;
DECLARE
    cursor useri_1 is select * from useri;
    cursor useri_2 is select * from useri;
BEGIN
    for v_line in useri_1 loop
        for v_line2 in useri_2 loop
            dbms_output.put_line(in_comun(v_line.id, v_line2.id));
        end loop;
    end loop;
END;


