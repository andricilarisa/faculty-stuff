create or replace procedure duplicate_table (p_table1 varchar2) as
    TYPE columns_type IS table of all_tab_columns%rowtype
        index by pls_integer;
    v_columns columns_type;
    v_cursor int := dbms_sql.open_cursor;
    v_query varchar2(1000);
    v_select_list varchar2(1000);
    v_insert_list varchar2(1000);
    v_types varchar2(1000);
    f2 int;
    l_colCnt        number default 0;
    l_colDesc          dbms_sql.DESC_TAB;
    f UTL_FILE.FILE_TYPE;
    v_text varchar(4000);
    
    function is_string (row_in IN int)
        return boolean
    is
    begin
        return (v_columns (row_in).data_type in ('CHAR', 'VARCHAR2', 'VARCHAR'));
    end;
    
    function is_number (row_in IN int)
        return boolean
    is
    begin
        return (v_columns (row_in).data_type in ('INT', 'FLOAT', 'NUMBER'));
    end;
    
    function is_date (row_in IN int)
        return boolean
    is
    begin
        return (v_columns (row_in).data_type in ('DATE', 'TIMESTAMP'));
    end;
    
    function is_clob (row_in IN int)
        return boolean
    is
    begin
        return (v_columns (row_in).data_type in ('CLOB'));
    end;
    
    procedure load_column_info is
        l_index int;
        table_inexistent exception;
        pragma exception_init (table_inexistent, -942);
    begin
        select * 
        bulk collect into v_columns 
            from all_tab_columns where table_name = p_table1;
        l_index := v_columns.FIRST;
        if l_index is null 
        then
            raise table_inexistent;
        else
            while (l_index is not null)
            loop
                if v_select_list is null then
                    v_select_list := v_columns (l_index).column_name;
                    v_insert_list := ':' || v_select_list || '_bind';
                    
                else 
                    v_select_list := v_select_list || ', ' || v_columns (l_index).column_name;
                    v_insert_list := v_insert_list || ', :' || v_columns (l_index).column_name || '_bind';
                    
                end if;
                l_index := v_columns.NEXT(l_index);
            end loop;
        end if;
    end load_column_info;
    
    procedure parse_query is
    begin
        v_query := 'select ' || v_select_list || ' from ' || p_table1;
        dbms_sql.parse(v_cursor, v_query, dbms_sql.native);
    end parse_query;
    
    procedure execute_query is
        dummy int;
        l_index int;
    begin
        l_index := v_columns.FIRST;
        
        while (l_index is not null)
        loop
            if is_string (l_index)
            then 
                dbms_sql.define_column(v_cursor, l_index, 'a', 100);
            elsif is_clob(l_index)
            then
                dbms_sql.define_column(v_cursor, l_index, 'aw', 2000);
            elsif is_number (l_index)
            then
                dbms_sql.define_column(v_cursor, l_index, 1);
            else
            
                dbms_sql.define_column(v_cursor, l_index, sysdate);
            end if;
            
            l_index := v_columns.NEXT (l_index);
            
        end loop;
        
        f2:=dbms_sql.execute(v_cursor);
    end execute_query;
    
    procedure copy_table is
     v_string varchar2(2000);
        v_number int;
        v_date date;
        dummy int := 1;
        dummy2 int;
        l_index int;
        v_bind varchar2(100);
        v_ins varchar2(4000);
        templateMessage3 varchar2(1000);
    begin
        f := utl_file.fopen('MY_DIR', 'file7.sql', 'A', 30000);
        
        utl_file.put_line(f, DBMS_METADATA.GET_DDL('TABLE',p_table1) || ';');
        v_ins := 'insert into ' || p_table1 || '(' || v_select_list || ') VALUES (' || v_insert_list || ');';
        loop
            if dummy=0 then exit;
            end if;
            dummy := dbms_sql.fetch_rows (v_cursor);
            if dummy=0 then exit;
            end if;
            
            
            l_index:=v_columns.FIRST;
            
            while (l_index is not null)
            loop
                v_bind := ':' || v_columns (l_index).column_name || '_bind';
                
                if is_string (l_index)
                then
                    dbms_sql.column_value(v_cursor, l_index, v_string);
                    if v_string is null then v_ins := replace(v_ins, v_bind, 'null');
                    else
                        v_string := '''' || v_string || ''''; 
                        v_ins := replace(v_ins, v_bind, v_string);
                    end if;
                elsif is_clob(l_index)
                then
                    dbms_sql.column_value(v_cursor, l_index, v_string);
                    if v_string is null then v_ins :=replace(v_ins, v_bind, 'null');
                    else 
                        v_string :=replace(v_string, '''', '+');
                        v_string :=replace(v_string,'&', '');
                        v_string :=replace(v_string,'\n', ' ');
                        v_string :=replace(v_string,';', '');
                        v_string := '''' || v_string || ''''; 
                        v_ins := replace(v_ins, v_bind, v_string);
                    end if;
                elsif is_number (l_index)
                then
                    dbms_sql.column_value(v_cursor, l_index, v_number);
                    if v_number is null then v_ins := replace(v_ins, v_bind, 'null');
                    else
                        v_string := to_char(v_number);
                        v_ins := replace(v_ins, v_bind, v_string);
                    end if;
                    
                else                
                    dbms_sql.column_value(v_cursor, l_index, v_date);
                    if v_date is null then v_ins := replace(v_ins, v_bind, 'null');
                    else
                        v_string := to_char(v_date);
                        v_string:= 'to_timestamp(''' || v_string || ''')';
                        v_ins := replace(v_ins, v_bind, v_string);
                    end if;
                end if;
                l_index := v_columns.next(l_index);
            end loop;
            utl_file.put_line(f, v_ins);
            UTL_FILE.FFLUSH(f);
            v_ins := 'insert into ' || p_table1 || '(' || v_select_list || ') VALUES (' || v_insert_list || ');';
        end loop;
        commit;
        utl_file.put_line(f, ' ');
        utl_file.fclose(f);
    end copy_table;
    
begin
    load_column_info;
    parse_query;
    execute_query;
    copy_table;
    dbms_sql.close_cursor(v_cursor);

end;
     
set serveroutput on;
declare
    cursor tabele is select table_name from user_tables;
    cursor trigere is select trigger_name from user_triggers;
    cursor proceduri2 is select object_name from user_objects where object_type='PROCEDURE';
    cursor views1 is select object_name from user_objects where object_type='VIEW';
    cursor functions1 is select object_name from user_objects where object_type='FUNCTION';
    f UTL_FILE.FILE_TYPE;
    v_text varchar(4000);
begin
    for v_line in tabele loop
        duplicate_table(v_line.table_name);
    end loop;
    f := utl_file.fopen('MY_DIR', 'file7.sql', 'A', 30000);
    for v_line in trigere loop
        select DBMS_METADATA.GET_DDL('TRIGGER',v_line.TRIGGER_NAME) into v_text from dual;        
        utl_file.put_line(f, v_text||';');
        UTL_FILE.FFLUSH(f);
        utl_file.put_line(f, ' ');
    end loop;
    for v_line in proceduri2 loop
        utl_file.put_line(f,  DBMS_METADATA.GET_DDL('PROCEDURE',v_line.OBJECT_NAME)||';');
        UTL_FILE.FFLUSH(f);
        utl_file.put_line(f, ' ');
    end loop;
    for v_line in views1 loop
        utl_file.put_line(f, DBMS_METADATA.GET_DDL('VIEW',v_line.OBJECT_NAME)||';');
        UTL_FILE.FFLUSH(f);
        utl_file.put_line(f, ' ');
    end loop;
    for v_line in functions1 loop
        utl_file.put_line(f, DBMS_METADATA.GET_DDL('FUNCTION',v_line.OBJECT_NAME)||';');
        UTL_FILE.FFLUSH(f);
        utl_file.put_line(f, ' ');
    end loop;    
    utl_file.fclose(f);
end;
