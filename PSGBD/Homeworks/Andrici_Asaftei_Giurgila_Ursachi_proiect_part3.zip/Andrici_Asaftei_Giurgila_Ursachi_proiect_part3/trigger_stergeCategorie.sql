CREATE OR REPLACE TRIGGER sterge_categorie
    BEFORE DELETE ON CATEGORII
    FOR EACH ROW
DECLARE
    cursor c_produse is select * from PRODUSE where PRODUSE.id_categorie=:old.id_categorie;
    cursor c_proprietati is select * from PROPRIETATI where PROPRIETATI.id_categorie=:old.id_categorie;
BEGIN
     for v_line in c_produse loop
        delete from PRODUS_PROP where PRODUS_PROP.id_produs=v_line.id;
    end loop;
    delete from PRODUSE where PRODUSE.id_categorie=:old.id_categorie;
    for v_line in c_proprietati loop
        delete from RESTRICTII where RESTRICTII.id_prop=v_line.id_prop;
        delete from PREFERINTE where PREFERINTE.id_prop=v_line.id_prop;
        delete from PRODUS_PROP where PRODUS_PROP.id_prop=v_line.id_prop;
    end loop;
    delete from PROPRIETATI where PROPRIETATI.id_categorie=:old.id_categorie;
END;


delete from categorii where id_categorie = 6;

select * from categorii where id_categorie = 6;
select * from produse where id_categorie = 6;