--view materializat

drop MATERIALIZED VIEW view_useri;
/
CREATE MATERIALIZED VIEW view_useri FOR UPDATE AS 
    SELECT * FROM useri;
    
    insert into view_useri values (10001, 'testPeView', 'Gigi Mamaliga', sysdate, sysdate,
    'mamaaremere','lenes', sysdate, 'gigi@lenes.ro');
    
    select * from view_useri where id=10001;
    delete from view_useri where id=10001;
    
    